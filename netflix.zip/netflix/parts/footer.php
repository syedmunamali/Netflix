<footer>
  <div class="container-fluid">
    <div class="row">
      <p>Questions? Contact Us.</p>
      <div class="col-md-3">
        <ul>
          <li>Faq</li>
          <li>Investor Relations</li>
          <li>Privacy</li>
          <li>Speed Test</li>
        </ul>
      </div>
      <div class="col-md-3">
        <ul>
          <li>Help Center</li>
          <li>Jobs</li>
          <li>Cookie Preferences</li>
          <li>Legal Notices</li>
        </ul>
      </div>
      <div class="col-md-3">
        <ul>
          <li>Account</li>
          <li>Ways to Watch</li>
          <li>Corporate Information</li>
          <li>Only on Netflix</li>
        </ul>
      </div>
      <div class="col-md-3">
        <ul>
          <li>Media Center</li>
          <li>Terms of Use</li>
          <li>Contact Us</li>
        </ul>
      </div>
      <p>Netflix Pakistan</p>
    </div>
  </div>
</footer>