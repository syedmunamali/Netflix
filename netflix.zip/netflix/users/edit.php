<?php include '../parts/config.php'; ?>
<?php include '../parts/header.php'; ?>

<h2>Please Edit the form..</h2>
<?php

$sql = "SELECT * FROM users where id = " . $_GET['id'];
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) { ?>
    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <form action="editsave.php?id=<?php echo $row['id']; ?>" method="post">
            <div class="form-group">
                <label for="email">Email address:</label>
                <input type="email" class="form-control" value="<?php echo $row['email']; ?>" id="email" name="email">
            </div>
            <div class="form-group">
                <label for="pwd">Password:</label>
                <input type="password" class="form-control" id="pwd" name="password">
            </div>
            <div class="form-group">
                <label for="pwd">First Name:</label>
                <input type="text" class="form-control" name="first_name" value="<?php echo $row['first']; ?>">
            </div>

            <button type="submit" class="btn btn-default">Submit</button>
        </form>
    <?php } ?>
<?php } ?>
<?php include '../parts/footer.php'; ?>