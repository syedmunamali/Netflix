<?php include '../parts/config.php'; ?>

<?php

$sql = "INSERT INTO users (email, password, first)
VALUES ('" . $_POST['email'] . "', '" . md5($_POST['password']) . "','" . $_POST['first'] . "')";

if (mysqli_query($conn, $sql)) {
    //echo "New record created successfully";
    header("location:".$base_url."products/add.php?msg=yes");
} else {
   // echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    header("location:".$base_url."products/add.php?msg=no");
}

mysqli_close($conn);
?>