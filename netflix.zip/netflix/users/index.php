<?php include '../parts/config.php'; ?>
<?php include '../parts/header.php'; ?>

<h2 class="text index-product">Users Listing</h2>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th class="white">Sr.</th>
                            <th class="white">Email</th>
                            <th class="white">First Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php

                        $sql = "SELECT * FROM users";
                        $result = mysqli_query($conn, $sql);

                        if (mysqli_num_rows($result) > 0) {
                            $count=0;
                            // output data of each row
                            while ($row = mysqli_fetch_assoc($result)) { ?>
                                <tr>
                                    <td><?php echo ++$count; ?></td>
                                    <td><?php echo $row["email"]; ?></td>
                                    <td><?php echo $row["first"]; ?></td>
                                    <td>
                                        <a href="<?php echo $base_url; ?>users/edit.php?id=<?php echo $row['id']; ?>"><span class="glyphicon glyphicon-edit"></span></a>
                                        <a href="<?php echo $base_url; ?>users/delete.php?id=<?php echo $row['id']; ?>"><span class="glyphicon glyphicon-trash"></span></a>
                                    </td>
                                </tr>

                        <?php
                            }
                        } else {
                            echo "0 results";
                        }

                        ?>




                         
                    </tbody>
                </table>

                <?php include '../parts/footer.php'; ?>