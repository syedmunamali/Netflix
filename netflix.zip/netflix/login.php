<?php include 'parts/header.php'; ?>

<div class="container topmargin">
    <div class="row">
        <div class="col-md-12">
            <?php if (isset($_GET['msg']) && ($_GET['msg'] == 'yes')) { ?>
                <div class="alert alert-success">
                    <strong>Success!</strong> Indicates a successful or positive action.
                </div>
            <?php } ?>
            <?php if (isset($_GET['msg']) && ($_GET['msg'] == 'no')) { ?>
                <div class="alert alert-danger">
                    <strong>Alert!</strong> Invalid login details.
                </div>
            <?php } ?>
            <h2>Please Login</h2>
            <form action="verify.php" method="post">
                <div class="form-group">
                    <label for="email">Email address:</label>
                    <input type="email" class="form-control" id="email" name="email">
                </div>
                <div class="form-group">
                    <label for="pwd">Password:</label>
                    <input type="password" class="form-control" id="pwd" name="password">
                </div>
                <button type="submit" class="btn btn-default">Submit</button>
            </form>
        </div>
    </div>
</div>
<?php include 'parts/footer.php'; ?>