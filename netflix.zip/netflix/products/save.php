<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "netflix";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


echo "<pre>";
print_r($_FILES);
echo "</pre>";
$file = '';
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["product"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
if (move_uploaded_file($_FILES["product"]["tmp_name"], $target_file)) {
    $file = $target_file;
}

$sql = "INSERT INTO users (email, password, first)
VALUES ('" . $_POST['email'] . "', '" . md5($_POST['password']) . "','" . $_POST['first'] . "')";

if (mysqli_query($conn, $sql)) {
    //echo "New record created successfully";
    header("location:" . $base_url . "products/add.php?msg=yes");
} else {
    // echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    header("location:" . $base_url . "products/add.php?msg=no");
}

mysqli_close($conn);
