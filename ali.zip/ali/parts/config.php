<?php session_start();
$base_url = "http://localhost/ali/";
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "alidb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}




?>