<?php include 'parts/header.php'; ?>
<style>
    .topmargin {
        margin-top: 50px;
    }
</style>

<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

    <?php include 'parts/nav.php'; ?>

    <div class="container topmargin">
        <div class="row">
            <div class="col-md-12">
                <?php if (isset($_GET['msg']) && ($_GET['msg'] == 'yes')) { ?>
                    <div class="alert alert-success">
                        <strong>Success!</strong> Indicates a successful or positive action.
                    </div>
                <?php } ?>
                <h2>Please Fill in the form..</h2>
                <form action="saveproduct.php" method="post">
                    <div class="form-group">
                        <label for="email">Email address:</label>
                        <input type="email" class="form-control" id="email" name="email">
                    </div>
                    <div class="form-group">
                        <label for="pwd">First Name:</label>
                        <input type="text" class="form-control" name="firstName">
                    </div>
                    <div class="form-group">
                        <label for="pwd">Country:</label>
                        <select class="form-control" name="country">
                            <option>Please select</option>
                            <option value="Pakistan">Pakistan</option>
                            <option value="Germany">Germany</option>
                            <option value="Korea">Korea</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-default">Submit</button>
                </form>
            </div>
        </div>
    </div>
    <?php include 'parts/footer.php'; ?>