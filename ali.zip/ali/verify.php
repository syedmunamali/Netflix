<?php

include 'parts/config.php';

$sql = "select * from users where email='" . $_REQUEST['email'] . "' and password = '" . md5($_REQUEST['password']) . "'";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while ($row = mysqli_fetch_assoc($result)) {
        $_SESSION['id'] =  $row["id"];
        $_SESSION['first_name'] =  $row["first_name"];
        $_SESSION['email'] =  $row["email"];
        header("location:" . $base_url . "products/index.php?msg=yes");
        exit;
        //echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
    }
} else {
    header("location:" . $base_url . "login.php?msg=no");
    exit;
    echo "0 results";
}
