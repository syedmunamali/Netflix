<?php include '../parts/config.php'; ?>
<?php include '../parts/header.php'; ?>
<style>
    .topmargin {
        margin-top: 50px;
    }
</style>

<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

    <?php include '../parts/nav.php'; ?>

    <div class="container topmargin">
        <div class="row">
            <div class="col-md-12">
                <?php if (isset($_GET['msg']) && ($_GET['msg'] == 'yes')) { ?>
                    <div class="alert alert-success">
                        <strong>Success!</strong> Indicates a successful or positive action.
                    </div>
                <?php } ?>
                <h2>Users Listing</h2>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Sr.</th>
                            <th>First Name</th>
                            <th>Email</th>
                            <th>Country</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php

                        $sql = "SELECT * FROM users";
                        $result = mysqli_query($conn, $sql);

                        if (mysqli_num_rows($result) > 0) {
                            $count=0;
                            // output data of each row
                            while ($row = mysqli_fetch_assoc($result)) { ?>
                                <tr>
                                    <td><?php echo ++$count; ?></td>
                                    <td><?php echo $row["first_name"]; ?></td>
                                    <td><?php echo $row["email"]; ?></td>
                                    <td><?php echo $row["country"]; ?></td>
                                    <td>
                                        <a href="<?php echo $base_url; ?>users/edit.php?id=<?php echo $row['id']; ?>"><span class="glyphicon glyphicon-edit"></span></a>
                                        <a href="<?php echo $base_url; ?>users/delete.php?id=<?php echo $row['id']; ?>"><span class="glyphicon glyphicon-trash"></span></a>
                                    </td>
                                </tr>

                        <?php
                            }
                        } else {
                            echo "0 results";
                        }

                        ?>




                         
                    </tbody>
                </table>





            </div>
        </div>
    </div>
    <?php include '../parts/footer.php'; ?>