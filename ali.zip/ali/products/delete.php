
<?php
include "../parts/config.php";

$sql = "delete from users where id=" . $_GET['id'];
//$base_url . "users/index.php?msg=yes;

if (mysqli_query($conn, $sql)) {
    //echo "New record created successfully";
    header("location:" . $base_url . "users/index.php?msg=yes");
} else {
    // echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    header("location:" . $base_url . "users/index.php?msg=no");
    // header("location:http://localhost:8080/bsit5/myform.php?msg=no");
}
