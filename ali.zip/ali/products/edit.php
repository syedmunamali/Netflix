<?php include '../parts/config.php'; ?>
<?php include '../parts/header.php'; ?>
<style>
    .topmargin {
        margin-top: 50px;
    }
</style>

<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

    <?php include '../parts/nav.php'; ?>

    <div class="container topmargin">
        <div class="row">
            <div class="col-md-12">
                <?php if (isset($_GET['msg']) && ($_GET['msg'] == 'yes')) { ?>
                    <div class="alert alert-success">
                        <strong>Success!</strong> Indicates a successful or positive action.
                    </div>
                <?php } ?>
                <h2>Please Edit the form..</h2>
                <?php

                $sql = "SELECT * FROM users where id = " . $_GET['id'];
                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) > 0) { ?>
                    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                        <form action="editsave.php?id=<?php echo $row['id']; ?>" method="post">
                            <div class="form-group">
                                <label for="email">Email address:</label>
                                <input type="email" class="form-control" value="<?php echo $row['email']; ?>" id="email" name="email">
                            </div>
                            <div class="form-group">
                                <label for="pwd">Password:</label>
                                <input type="password" class="form-control" id="pwd" name="password">
                            </div>
                            <div class="form-group">
                                <label for="pwd">First Name:</label>
                                <input type="text" class="form-control" name="first_name" value="<?php echo $row['first_name']; ?>">
                            </div>
                            <div class="form-group">
                                <label for="pwd">Country:</label>
                                <select class="form-control" name="country">
                                    <option>Please select</option>
                                    <option value="Pakistan" <?php if ($row['country'] == "Pakistan") {
                                                                    echo "selected";
                                                                } ?>>Pakistan</option>
                                    <option value="Germany" <?php if ($row['country'] == "Germany") {
                                                                echo "selected";
                                                            } ?>>Germany</option>
                                    <option value="Korea" <?php if ($row['country'] == "Korea") {
                                                                echo "selected";
                                                            } ?>>Korea</option>
                                </select>
                            </div>

                            <button type="submit" class="btn btn-default">Submit</button>
                        </form>
                    <?php } ?>
                <?php } ?>
            </div>
        </div>
    </div>
    <?php include '../parts/footer.php'; ?>