<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "alidb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


echo "<pre>";
print_r($_FILES);
echo "</pre>";
$file = '';
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["product"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
if(move_uploaded_file($_FILES["product"]["tmp_name"], $target_file)){
    $file = $target_file;
}



$sql = "INSERT INTO users (email, password, first_name,country,image)
VALUES ('" . $_POST['email'] . "', '" . md5($_POST['password']) . "', '" . $_POST['first_name'] . "', '" . $_POST['country'] . "','".$file."')";

if (mysqli_query($conn, $sql)) {
    //echo "New record created successfully";
    header("location:".$base_url."product/index.php?msg=yes");
} else {
   // echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    header("location:http://localhost:8080/bsit5/myform.php?msg=no");
}

mysqli_close($conn);



// echo "<pre>";
// //print_r($_GET);
// print_r($_POST);


// echo "</pre>";

// echo $_POST['email'];
// echo "<br />";

// echo $_POST['password'];
// echo "<br />";

// echo $_POST['first_name'];
// echo "<br />";

// echo $_POST['email'];
// echo "<br />";
