<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bsit5db";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO users (email, password, first_name,country)
VALUES ('" . $_POST['email'] . "', '" . md5($_POST['password']) . "', '" . $_POST['first_name'] . "', '" . $_POST['country'] . "')";

if (mysqli_query($conn, $sql)) {
    //echo "New record created successfully";
    header("location:http://localhost:8080/bsit5/myform.php?msg=yes");
} else {
   // echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    header("location:http://localhost:8080/bsit5/myform.php?msg=no");
}

mysqli_close($conn);



// echo "<pre>";
// //print_r($_GET);
// print_r($_POST);


// echo "</pre>";

// echo $_POST['email'];
// echo "<br />";

// echo $_POST['password'];
// echo "<br />";

// echo $_POST['first_name'];
// echo "<br />";

// echo $_POST['email'];
// echo "<br />";
